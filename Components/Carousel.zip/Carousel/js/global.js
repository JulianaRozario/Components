$(document).ready(function () {
    var owl = $('.owl-carousel');
    owl.owlCarousel({
      items:3,
            loop:true,
           
            dots:false,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 2000,
            autoplaySpeed: 2000,
            autoplayHoverPause: true,
     
     
    });
  

});